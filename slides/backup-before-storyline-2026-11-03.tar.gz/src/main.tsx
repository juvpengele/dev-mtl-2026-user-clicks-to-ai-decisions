import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Deck } from './deck/Deck'
import { Presenter } from './deck/Presenter'
import './theme.css'
import './presenter.css'

const isPresenter = new URLSearchParams(location.search).has('presenter')

createRoot(document.getElementById('root')!).render(
  <StrictMode>{isPresenter ? <Presenter /> : <Deck />}</StrictMode>,
)
