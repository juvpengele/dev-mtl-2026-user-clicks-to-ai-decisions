Speaker notes. Each "## <slide-id>" heading holds the notes for that slide (see src/slides/).
"Click" = one step on that slide.

## cold-open
Walk on with the screen black. Pause. Click: the line types in.
Let it sit for a beat before you speak.

## title
Introduce yourself. One sentence on what this talk is: following one click from the browser all the way to an AI's decision.

## client
Set the story: a real, small request from the organizers. A seat reservation app.

## built-by-ai
Click: the reviewer line. Click: the green check draws.
"Everything passed. So we're done, right?"

## how-will-you-know
Slow. Let the question land. Nobody in the room can answer it from a green checkmark.

## three-signals
The classic three signals. Click: we're going to focus on one: traces.
Traces answer "what happened to THIS request", across every service it touched.

## architecture
Three boxes, nothing fancy. Click: one request travels through all three. That path is one trace.

## traceparent
How does the server know it's the same request? A header.
Click: highlight traceparent (W3C Trace Context: version, trace id, parent span id, flags).
Click: the trace id is the ticket. Browser hands it to the server; the server continues the same trace.

## demo-click
SWITCH TO THE LIVE APP.
Click "Reserve seat", open Jaeger, find the trace, show the browser span with the server span under it.

## instrumentation
This is the whole server setup.
Clicks walk through: register() (Next.js calls it once at startup) → Node runtime only (edge has no Node SDK) → serviceName (what you'll search for) → OTLP exporter (vendor-neutral wire format) → auto-instrumentations (http, fetch, pg spans for free) → start.
If anyone asks: in a real project, put the Node-only imports in a separate file and import it dynamically inside register().

## waterfall
Read the waterfall: time goes left to right, children nest under parents.
The browser span wraps everything: this is what the user actually felt.

## local-to-cloud
The app only speaks OTLP to a Collector. The Collector fans out.
Click: add Azure Application Insights. It's Collector config, not app code: code changes, zero.

## demo-cloud
SWITCH TO THE LIVE APP.
Show the same trace id in Application Insights (transaction search / end-to-end view).

## slow-page
The hardest bug report: nothing is broken.

## n-plus-one
Local first: 10 events, 11 queries, ~230 ms. Looks fine.
Click: production, 100 events. Let the cascade run. Don't talk over it.
Click: name it. N+1: one query for the list, then one per event.

## n-plus-one-code
The code looks innocent. Click: the loop. Click: the await inside it: one database round trip per event.

## who-decided-again
Callback to the opening. Who wrote that loop? An agent. Who approved it? An agent. Who noticed? Nobody, until a user complained.

## agent-mcp
Give the agent the same evidence you have.
Click: an MCP server exposes tools over the traces: search_traces, find_errors.

## demo-agent
SWITCH TO THE AGENT.
Paste the prompt. Let it call search_traces, find the N+1 in the trace, propose the fix.
Read its reasoning out loud; point at the spans it cites.

## fixed
Same request, same scale. Click: 101 query spans collapse into one (LEFT JOIN + GROUP BY). ~1.9 s → ~50 ms.

## loop
Build the loop one click at a time.
Last click: "Human decides". The agent found it and proposed it; you decided to ship it.

## takeaways
One per click.
1. Start the trace in the browser: that's where the user's time starts.
2. OpenTelemetry: you just saw one Collector config change move us to a different vendor.
3. Good span names and attributes are for your future self and for the agent reading them.

## closing
Slow. Say it once. Stop.

## thanks
Point to the QR code: demo repo. Take questions.
