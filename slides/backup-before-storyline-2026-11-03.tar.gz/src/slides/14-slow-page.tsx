import { motion } from 'motion/react'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

function SlowPage() {
  const { initial, t } = useSlide()
  return (
    <div className="slide">
      <motion.div
        initial={initial === false ? false : { opacity: 0, x: 900 }}
        animate={{ opacity: 1, x: 0 }}
        transition={t.spring('soft', 0.3)}
        style={{
          width: 1360,
          display: 'flex',
          gap: 40,
          padding: '48px 56px',
          background: 'var(--surface)',
          border: '2px solid var(--surface-2)',
          borderRadius: 40,
          boxShadow: '0 40px 120px rgba(0,0,0,0.7)',
        }}
      >
        <span
          style={{
            flex: 'none',
            width: 112,
            height: 112,
            borderRadius: 28,
            background: 'var(--surface-2)',
            border: '2px solid var(--line)',
            display: 'grid',
            placeItems: 'center',
            fontSize: 40,
            fontWeight: 800,
          }}
        >
          DM
        </span>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span style={{ fontSize: 40, fontWeight: 700 }}>DevMTL organizers</span>
            <span className="mono" style={{ fontSize: 28, color: 'var(--muted)' }}>
              now
            </span>
          </div>
          <div style={{ fontSize: 60, fontWeight: 550, lineHeight: 1.3, marginTop: 16, color: 'var(--ink-2)' }}>
            The events page is slow. Not broken. <span style={{ color: 'var(--ink)', fontWeight: 750 }}>Just slow.</span>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

export default { id: 'slow-page', title: '"The events page is slow"', steps: 1, Component: SlowPage } satisfies SlideDef
