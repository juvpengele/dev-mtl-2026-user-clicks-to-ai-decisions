import { DemoCue } from '../components/DemoCue'
import type { SlideDef } from '../deck/types'

export default {
  id: 'demo-click',
  title: 'Demo: the click',
  steps: 1,
  Component: () => <DemoCue title="the click" />,
} satisfies SlideDef
