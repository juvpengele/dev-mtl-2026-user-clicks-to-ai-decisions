import { CodeBlock } from '../components/CodeBlock'
import type { SlideDef } from '../deck/types'

const CODE = `export async function getEvents() {
  const events = await db.query('SELECT * FROM events')

  for (const event of events) {
    event.seatsTaken = await db.query(
      'SELECT count(*) FROM reservations WHERE event_id = $1',
      [event.id],
    )
  }

  return events
}
`

const STEPS = [
  { lines: [] },
  { lines: [4, 5, 6, 7, 8, 9] }, // the loop
  { lines: [4, 5, 6, 7, 8, 9], pulse: [5, 6, 7, 8] }, // one round trip per event
]

export default {
  id: 'n-plus-one-code',
  title: 'The loop',
  steps: STEPS.length,
  Component: () => (
    <div className="slide">
      <CodeBlock code={CODE} filename="lib/events.ts" steps={STEPS} fontSize={38} />
    </div>
  ),
} satisfies SlideDef
