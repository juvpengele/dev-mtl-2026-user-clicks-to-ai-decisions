import { motion } from 'motion/react'
import { DrawPath, Svg } from '../components/Diagram'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

const C = { x: 960, y: 560, rx: 560, ry: 340 }
const rad = (deg: number) => (deg * Math.PI) / 180
const pt = (deg: number): [number, number] => [C.x + C.rx * Math.cos(rad(deg)), C.y + C.ry * Math.sin(rad(deg))]

/** Clockwise arc along the ellipse, plus an arrowhead tangent to it at the end. */
function arc(a1: number, a2: number) {
  const [x1, y1] = pt(a1)
  const [x2, y2] = pt(a2)
  const head = (Math.atan2(C.ry * Math.cos(rad(a2)), -C.rx * Math.sin(rad(a2))) * 180) / Math.PI
  return { d: `M${x1},${y1} A${C.rx},${C.ry} 0 0 1 ${x2},${y2}`, end: [x2, y2] as const, head }
}

// Nodes sit at the top, right, bottom and left of the ellipse. Wider gaps at
// the top and bottom, where the labels are wide.
const NODES = [
  { deg: -90, text: 'AI writes the code' },
  { deg: 0, text: 'Observability records what it does' },
  { deg: 90, text: 'AI reads the traces' },
  { deg: 180, text: 'Human decides' },
]
const ARCS = [arc(-58, -26), arc(26, 58), arc(122, 154), arc(206, 238)]
// [step, delay] for each arc: arcs 1–3 lead into nodes 2–4; the last one closes the loop.
const ARC_AT: [number, number][] = [
  [1, 0],
  [2, 0],
  [3, 0],
  [3, 1.2],
]
const EMPHASIS_DELAY = 2.2

function ArcArrow({ i }: { i: number }) {
  const { step, initial, t } = useSlide()
  const [at, delay] = ARC_AT[i]
  const { d, end, head } = ARCS[i]
  return (
    <g>
      <DrawPath d={d} at={at} delay={delay} width={5} />
      <motion.path
        d="M-24,-14 L0,0 L-24,14"
        fill="none"
        stroke="var(--line)"
        strokeWidth={5}
        strokeLinecap="round"
        strokeLinejoin="round"
        transform={`translate(${end[0]},${end[1]}) rotate(${head})`}
        initial={initial}
        animate={step >= at ? 'shown' : 'hidden'}
        variants={{ hidden: { opacity: 0 }, shown: { opacity: 1 } }}
        transition={t.spring('snappy', delay + 0.9)}
      />
    </g>
  )
}

function Loop() {
  const { step, initial, t } = useSlide()
  const emphasis = step >= 3
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Svg>
        {ARCS.map((_, i) => (
          <ArcArrow key={i} i={i} />
        ))}
      </Svg>
      {NODES.map((n, i) => {
        const [x, y] = pt(n.deg)
        const human = i === 3
        return (
          <motion.div
            key={i}
            initial={initial}
            animate={step >= i ? 'shown' : 'hidden'}
            variants={{ hidden: { opacity: 0, scale: 0.7 }, shown: { opacity: 1, scale: 1 } }}
            transition={t.spring('bouncy', i === 0 ? 0 : 0.8)}
            style={{
              position: 'absolute',
              left: x - (human ? 300 : 260),
              top: y - 80,
              width: human ? 600 : 520,
              height: 160,
              display: 'grid',
              placeItems: 'center',
              textAlign: 'center',
            }}
          >
            <motion.span
              animate={
                human && emphasis
                  ? { scale: 1.18, color: '#f6f7f9', textShadow: '0 0 48px rgba(246,247,249,0.45)' }
                  : { scale: 1, color: human ? '#f6f7f9' : '#b9c0cc', textShadow: '0 0 0px rgba(246,247,249,0)' }
              }
              transition={t.spring('bouncy', human && emphasis ? EMPHASIS_DELAY : 0)}
              style={{ display: 'inline-block', fontSize: human ? 72 : 48, fontWeight: human ? 800 : 650, lineHeight: 1.2 }}
            >
              {n.text}
            </motion.span>
          </motion.div>
        )
      })}
    </div>
  )
}

export default { id: 'loop', title: 'The full loop', steps: 4, Component: Loop } satisfies SlideDef
