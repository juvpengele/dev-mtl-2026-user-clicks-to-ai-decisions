import { motion } from 'motion/react'
import { DrawPath } from '../components/Diagram'
import { Words } from '../components/Words'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

function BuiltByAi() {
  const { step, initial, t } = useSlide()
  return (
    <div className="slide">
      <Words text="Built by an AI agent." className="title" highlight={{ AI: 'accent' }} />
      <Words text="Reviewed by an AI agent." className="title" at={1} highlight={{ AI: 'accent' }} style={{ marginTop: 16 }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 40, marginTop: 80, height: 260 }}>
        <svg viewBox="0 0 260 260" width={260} height={260} style={{ filter: step >= 2 ? 'drop-shadow(0 0 28px rgba(61,220,132,0.45))' : undefined }}>
          <DrawPath d="M130,20 A110,110 0 1,1 129.9,20" at={2} stroke="var(--ok)" width={12} />
          <DrawPath d="M78,135 L115,172 L185,96" at={2} delay={0.45} stroke="var(--ok)" width={18} spring="soft" />
        </svg>
        <motion.div
          className="mono"
          initial={initial}
          animate={step >= 2 ? 'shown' : 'hidden'}
          variants={{ hidden: { opacity: 0, x: -20 }, shown: { opacity: 1, x: 0 } }}
          transition={t.spring('soft', 0.9)}
          style={{ fontSize: 48, color: 'var(--ok)' }}
        >
          All checks passed
        </motion.div>
      </div>
    </div>
  )
}

export default { id: 'built-by-ai', title: 'Built & reviewed by AI', steps: 3, Component: BuiltByAi } satisfies SlideDef
