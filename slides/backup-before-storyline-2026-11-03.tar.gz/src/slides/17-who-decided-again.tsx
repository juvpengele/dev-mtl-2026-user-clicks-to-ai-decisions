import type { SlideDef } from '../deck/types'
import { WhoDecided } from './WhoDecided'

export default {
  id: 'who-decided-again',
  title: 'Who made the decision? (callback)',
  steps: 1,
  Component: () => <WhoDecided delay={0.6} />,
} satisfies SlideDef
