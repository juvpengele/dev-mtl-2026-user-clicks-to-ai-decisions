import { motion } from 'motion/react'
import { Arrow, NodeBox, Svg } from '../components/Diagram'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

const Y = 420
const BOTTOM = Y + 85
const LANE = 640

// The trace runs under the boxes and dips into each one it passes through.
const POINTS: [number, number][] = [
  [360, BOTTOM],
  [360, LANE],
  [960, LANE],
  [960, BOTTOM],
  [960, LANE],
  [1560, LANE],
  [1560, BOTTOM],
]
const PATH = 'M' + POINTS.map(([x, y]) => `${x},${y}`).join(' L')
const SEGMENTS = POINTS.slice(1).map(([x, y], i) => Math.hypot(x - POINTS[i][0], y - POINTS[i][1]))
const TOTAL = SEGMENTS.reduce((a, b) => a + b, 0)
const TIMES = [0, ...SEGMENTS.map((_, i) => SEGMENTS.slice(0, i + 1).reduce((a, b) => a + b, 0) / TOTAL)]
const TRAVEL = 2.6

function Architecture() {
  const { step, initial, t } = useSlide()
  const state = step >= 1 ? 'shown' : 'hidden'
  return (
    <Svg>
      <motion.path
        d={PATH}
        fill="none"
        stroke="var(--trace)"
        strokeWidth={6}
        strokeLinejoin="round"
        strokeLinecap="round"
        style={{ filter: 'drop-shadow(0 0 12px var(--trace-glow))' }}
        initial={initial}
        animate={state}
        variants={{ hidden: { pathLength: 0, opacity: 0 }, shown: { pathLength: 1, opacity: 1 } }}
        transition={{ pathLength: t.tween(TRAVEL, 0.2, 'linear'), opacity: t.tween(0.15, 0.2) }}
      />
      <NodeBox cx={360} cy={Y} w={420} label="Browser" sub="React" />
      <NodeBox cx={960} cy={Y} w={420} label="Next.js server" sub="API route" delay={0.25} />
      <NodeBox cx={1560} cy={Y} w={420} label="Database" sub="Postgres" delay={0.5} />
      <Arrow from={[590, Y]} to={[730, Y]} delay={0.45} />
      <Arrow from={[1190, Y]} to={[1330, Y]} delay={0.7} />
      <motion.circle
        r={18}
        fill="var(--trace)"
        style={{ filter: 'drop-shadow(0 0 16px var(--trace))' }}
        initial={initial}
        animate={state}
        variants={{
          hidden: { cx: POINTS[0][0], cy: POINTS[0][1], opacity: 0 },
          shown: {
            cx: POINTS.map((p) => p[0]),
            cy: POINTS.map((p) => p[1]),
            opacity: 1,
            transition: { ...t.tween(TRAVEL, 0.2, 'linear'), times: TIMES, opacity: t.tween(0.15, 0.2) },
          },
        }}
      />
      <motion.text
        x={960}
        y={LANE + 100}
        textAnchor="middle"
        fontSize={44}
        fontFamily="var(--font-mono)"
        fill="var(--trace)"
        initial={initial}
        animate={state}
        variants={{ hidden: { opacity: 0 }, shown: { opacity: 1 } }}
        transition={t.tween(0.4, TRAVEL + 0.3)}
      >
        one trace
      </motion.text>
    </Svg>
  )
}

export default { id: 'architecture', title: 'Architecture: one trace', steps: 2, Component: Architecture } satisfies SlideDef
