import { CodeBlock } from '../components/CodeBlock'
import type { SlideDef } from '../deck/types'

const CODE = `import { NodeSDK } from '@opentelemetry/sdk-node'
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http'
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node'

export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return

  const sdk = new NodeSDK({
    serviceName: 'devmtl-seats',
    traceExporter: new OTLPTraceExporter(),
    instrumentations: [getNodeAutoInstrumentations()],
  })

  sdk.start()
}
`

const STEPS = [
  { lines: [] },
  { lines: [5, 16] }, // Next.js calls register() once at startup
  { lines: [6] }, // Node runtime only
  { lines: [9] }, // the name you'll search for
  { lines: [10] }, // OTLP: vendor-neutral wire format
  { lines: [11] }, // http, fetch, pg... spans for free
  { lines: [14] },
]

export default {
  id: 'instrumentation',
  title: 'instrumentation.ts',
  steps: STEPS.length,
  Component: () => (
    <div className="slide">
      <CodeBlock code={CODE} filename="instrumentation.ts" steps={STEPS} fontSize={29} />
    </div>
  ),
} satisfies SlideDef
