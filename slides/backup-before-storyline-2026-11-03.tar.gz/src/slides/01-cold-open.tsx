import type { SlideDef } from '../deck/types'
import { WhoDecided } from './WhoDecided'

// Step 1 holds on black while you walk on; the click types the line.
export default {
  id: 'cold-open',
  title: 'Who made the decision?',
  steps: 2,
  Component: () => <WhoDecided at={1} />,
} satisfies SlideDef
