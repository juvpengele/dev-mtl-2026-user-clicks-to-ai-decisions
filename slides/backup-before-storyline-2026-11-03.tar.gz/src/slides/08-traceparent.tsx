import { motion } from 'motion/react'
import { Arrow, NodeBox, Svg } from '../components/Diagram'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

const TRACE_ID = '4bf92f3577b34da6a3ce929d0e0e4736'
const LINES: [string, string][] = [
  ['POST', '/api/reserve HTTP/1.1'],
  ['host:', 'seats.devmtl.ca'],
  ['content-type:', 'application/json'],
  ['traceparent:', `00-${TRACE_ID}-00f067aa0ba902b7-01`],
]
const TP = 3

// Card geometry (stage px), so the ticket can start exactly on the traceparent line.
const CARD = { left: 290, top: 450, width: 1340, padY: 40, lineH: 64 }
const TP_Y = CARD.top + CARD.padY + TP * CARD.lineH + CARD.lineH / 2
const TICKET = { w: 560, h: 104 }
const BOX_Y = 230
const LAND_Y = BOX_Y + 85 + 80

function Traceparent() {
  const { step, initial, t } = useSlide()
  const highlight = step >= 1
  const ticket = step >= 2
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Svg>
        <NodeBox cx={360} cy={BOX_Y} w={420} label="Browser" />
        <NodeBox cx={1560} cy={BOX_Y} w={420} label="Server" sub="Next.js" delay={0.15} accent={ticket} />
        <Arrow from={[590, BOX_Y]} to={[1330, BOX_Y]} delay={0.3} />
      </Svg>

      <motion.div
        className="mono"
        initial={initial === false ? false : { opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={t.spring('soft', 0.25)}
        style={{
          position: 'absolute',
          left: CARD.left,
          top: CARD.top,
          width: CARD.width,
          padding: `${CARD.padY}px 0`,
          background: 'var(--surface)',
          border: '2px solid var(--surface-2)',
          borderRadius: 24,
          fontSize: 31,
          lineHeight: `${CARD.lineH}px`,
          boxShadow: '0 40px 120px rgba(0,0,0,0.6)',
        }}
      >
        {LINES.map(([k, v], i) => {
          const isTp = i === TP
          return (
            <motion.div
              key={i}
              animate={{
                opacity: highlight && !isTp ? 0.25 : isTp && ticket ? 0.35 : 1,
                backgroundColor: highlight && isTp ? 'rgba(255,178,36,0.14)' : 'rgba(255,178,36,0)',
              }}
              transition={t.spring('snappy')}
              style={{ padding: '0 40px', whiteSpace: 'nowrap', position: 'relative' }}
            >
              <motion.span
                style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 10, background: 'var(--trace)', originY: 0 }}
                animate={{ scaleY: highlight && isTp ? 1 : 0 }}
                transition={t.spring('snappy')}
              />
              <span style={{ color: isTp && highlight ? 'var(--trace)' : 'var(--muted)' }}>{k}</span>{' '}
              <span style={{ color: 'var(--ink)' }}>{v}</span>
            </motion.div>
          )
        })}
      </motion.div>

      {/* The ticket: lifts off the traceparent line, rides to the Browser, then across to the Server. */}
      <motion.div
        initial={initial}
        animate={ticket ? 'shown' : 'hidden'}
        variants={{
          hidden: { opacity: 0, x: 0, y: 0, scale: 0.9, transition: t.tween(0.3) },
          shown: {
            opacity: 1,
            scale: 1,
            x: [0, 360 - 960, 1560 - 960],
            y: [0, LAND_Y - TP_Y, LAND_Y - TP_Y],
            transition: {
              x: { ...t.tween(2.4, 0.2), times: [0, 0.35, 1] },
              y: { ...t.tween(2.4, 0.2), times: [0, 0.35, 1] },
              opacity: t.tween(0.2, 0.2),
              scale: t.spring('bouncy', 0.2),
            },
          },
        }}
        style={{
          position: 'absolute',
          left: 960 - TICKET.w / 2,
          top: TP_Y - TICKET.h / 2,
          width: TICKET.w,
          height: TICKET.h,
          display: 'flex',
          alignItems: 'center',
          gap: 24,
          padding: '0 32px',
          background: 'var(--trace)',
          color: '#050608',
          borderRadius: 18,
          boxShadow: '0 0 40px var(--trace-glow)',
          // Ticket notches.
          maskImage: 'radial-gradient(circle 16px at 0 50%, transparent 15px, #000 16px), radial-gradient(circle 16px at 100% 50%, transparent 15px, #000 16px)',
          maskComposite: 'intersect',
        }}
      >
        <span className="mono" style={{ fontSize: 24, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', opacity: 0.7 }}>
          trace id
        </span>
        <span className="mono" style={{ fontSize: 36, fontWeight: 700 }}>
          {TRACE_ID.slice(0, 6)}…{TRACE_ID.slice(-4)}
        </span>
      </motion.div>

      <motion.div
        className="body"
        initial={initial}
        animate={ticket ? 'shown' : 'hidden'}
        variants={{ hidden: { opacity: 0, y: 10 }, shown: { opacity: 1, y: 0 } }}
        transition={t.tween(0.4, 2.7, 'easeOut')}
        style={{ position: 'absolute', left: 0, right: 0, top: 870, textAlign: 'center' }}
      >
        Same trace ID on both sides → <span className="accent">one trace</span>
      </motion.div>
    </div>
  )
}

export default { id: 'traceparent', title: 'The traceparent header', steps: 3, Component: Traceparent } satisfies SlideDef
