import { Words } from '../components/Words'
import type { SlideDef } from '../deck/types'

function Closing() {
  return (
    <div className="slide">
      <Words text="Observe the AI's decisions." className="title" stagger={0.24} spring="slow" highlight={{ Observe: 'accent' }} />
      <Words text="Don't just trust them." className="title" delay={1.3} stagger={0.24} spring="slow" style={{ marginTop: 16, color: 'var(--ink-2)' }} />
    </div>
  )
}

export default { id: 'closing', title: 'Closing line', steps: 1, Component: Closing } satisfies SlideDef
