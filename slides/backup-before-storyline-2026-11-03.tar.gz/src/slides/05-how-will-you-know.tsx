import { Words } from '../components/Words'
import type { SlideDef } from '../deck/types'

function HowWillYouKnow() {
  return (
    <div className="slide">
      <Words text="When it's live," className="title" stagger={0.28} spring="slow" style={{ color: 'var(--ink-2)' }} />
      <Words
        text="how will you know it works?"
        className="title"
        delay={1.1}
        stagger={0.3}
        spring="slow"
        highlight={{ works: 'accent' }}
        style={{ marginTop: 16 }}
      />
    </div>
  )
}

export default { id: 'how-will-you-know', title: 'How will you know?', steps: 1, Component: HowWillYouKnow } satisfies SlideDef
