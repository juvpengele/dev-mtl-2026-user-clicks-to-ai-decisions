import { Waterfall, type Span } from '../components/Waterfall'
import type { SlideDef } from '../deck/types'

const SPANS: Span[] = [
  { name: 'click: Reserve seat', service: 'browser', start: 0, dur: 186, depth: 0 },
  { name: 'POST /api/reserve', service: 'next.js', start: 14, dur: 158, depth: 1 },
  { name: 'SELECT events', service: 'postgres', start: 26, dur: 18, depth: 2 },
  { name: 'INSERT reservations', service: 'postgres', start: 52, dur: 34, depth: 2 },
  { name: 'UPDATE events', service: 'postgres', start: 94, dur: 22, depth: 2 },
]

export default {
  id: 'waterfall',
  title: 'Trace waterfall',
  steps: 1,
  Component: () => (
    <div className="slide left">
      <div className="label" style={{ marginBottom: 40 }}>
        trace <span style={{ color: 'var(--trace)' }}>4bf92f…4736</span> · 5 spans
      </div>
      <Waterfall spans={SPANS} maxMs={200} ticks={[0, 50, 100, 150, 200]} delay={0.4} />
    </div>
  ),
} satisfies SlideDef
