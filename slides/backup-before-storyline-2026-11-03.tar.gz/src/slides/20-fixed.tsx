import { motion } from 'motion/react'
import { NP, NPlusOneFrame, px, qStart, qTop, QueryCounter, Q_DUR, reqEnd } from '../components/NPlusOne'
import { useCountTo } from '../components/useCountTo'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

const BEFORE = { queries: 101, ms: reqEnd(101) }
const AFTER = { queries: 1, ms: 52 }
const FIXED_Q = { start: 12, dur: 28, h: 30 }

/** Same frame as the N+1 slide; on the click, the 101 query spans collapse into one. */
function Fixed() {
  const { step, initial, t } = useSlide()
  const fixed = step >= 1
  const queries = Math.round(useCountTo(fixed ? AFTER.queries : BEFORE.queries, { from: BEFORE.queries, backDuration: 1.1 }))
  const ms = useCountTo(fixed ? AFTER.ms : BEFORE.ms, { from: BEFORE.ms, backDuration: 1.1 })

  return (
    <NPlusOneFrame endMs={ms}>
      {Array.from({ length: 101 }, (_, i) => (
        <motion.div
          key={i}
          initial={false}
          animate={
            fixed
              ? { x: px(FIXED_Q.start) - px(qStart(i)), y: qTop(0) - qTop(i), opacity: 0 }
              : { x: 0, y: 0, opacity: 1 }
          }
          transition={{ default: t.tween(0.7, i * 0.003, 'easeIn'), opacity: t.tween(0.3, 0.4 + i * 0.003) }}
          style={{
            position: 'absolute',
            left: NP.left + px(qStart(i)),
            top: qTop(i),
            width: px(Q_DUR),
            height: NP.qH,
            borderRadius: 2,
            background: 'var(--bad)',
          }}
        />
      ))}
      <motion.div
        initial={initial}
        animate={fixed ? 'shown' : 'hidden'}
        variants={{ hidden: { opacity: 0, scaleY: 0.2 }, shown: { opacity: 1, scaleY: 1 } }}
        transition={t.spring('bouncy', 0.8)}
        style={{ position: 'absolute', left: NP.left + px(FIXED_Q.start), top: qTop(0), display: 'flex', alignItems: 'center', gap: 24 }}
      >
        <span style={{ width: px(FIXED_Q.dur), height: FIXED_Q.h, borderRadius: 6, background: 'var(--ok)' }} />
        <span className="mono" style={{ fontSize: 28, color: 'var(--ok)', whiteSpace: 'nowrap' }}>
          SELECT events LEFT JOIN reservations … GROUP BY
        </span>
      </motion.div>
      <QueryCounter
        queries={queries}
        ms={ms}
        note={fixed ? '100 events · one query' : '100 events · production'}
        color={fixed ? 'var(--ok)' : 'var(--bad)'}
      />
    </NPlusOneFrame>
  )
}

export default { id: 'fixed', title: 'Fixed: one query', steps: 2, Component: Fixed } satisfies SlideDef
