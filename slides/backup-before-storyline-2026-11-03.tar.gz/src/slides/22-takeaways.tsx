import { motion } from 'motion/react'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

const TAKEAWAYS = [
  'Start the trace where the user is.',
  'Use OpenTelemetry so your observability outlives your code and your vendors.',
  'Give your spans meaning, for humans and for agents.',
]

function Takeaways() {
  const { step, initial, t } = useSlide()
  return (
    <div className="slide left">
      <div className="label" style={{ marginBottom: 56 }}>
        Takeaways
      </div>
      {TAKEAWAYS.map((text, i) => (
        <motion.div
          key={i}
          initial={initial}
          animate={step >= i ? 'shown' : 'hidden'}
          variants={{ hidden: { opacity: 0, x: -40, filter: 'blur(12px)' }, shown: { opacity: 1, x: 0, filter: 'blur(0px)' } }}
          transition={t.spring('soft')}
          style={{ display: 'flex', gap: 48, alignItems: 'baseline', marginBottom: 64, maxWidth: 1560 }}
        >
          <span className="mono" style={{ fontSize: 64, fontWeight: 700, color: 'var(--muted)', flex: 'none' }}>
            {i + 1}.
          </span>
          <motion.span
            animate={{ color: step === i ? '#f6f7f9' : '#b9c0cc' }}
            transition={t.spring('soft')}
            style={{ fontSize: 64, fontWeight: 700, lineHeight: 1.2, letterSpacing: '-0.02em' }}
          >
            {text}
          </motion.span>
        </motion.div>
      ))}
    </div>
  )
}

export default { id: 'takeaways', title: 'Three takeaways', steps: TAKEAWAYS.length, Component: Takeaways } satisfies SlideDef
