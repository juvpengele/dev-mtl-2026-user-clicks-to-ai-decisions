import { DemoCue } from '../components/DemoCue'
import type { SlideDef } from '../deck/types'

export default {
  id: 'demo-agent',
  title: 'Demo: the agent',
  steps: 1,
  Component: () => <DemoCue title="the agent" prompt="Users say the events page is slow. Find out why." />,
} satisfies SlideDef
