import { DemoCue } from '../components/DemoCue'
import type { SlideDef } from '../deck/types'

export default {
  id: 'demo-cloud',
  title: 'Demo: same trace, in the cloud',
  steps: 1,
  Component: () => <DemoCue title="same trace, in the cloud" />,
} satisfies SlideDef
