import { motion } from 'motion/react'
import { Arrow, DrawPath, NodeBox, Svg } from '../components/Diagram'
import { Words } from '../components/Words'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

const Y = 380
const MCP_BOTTOM = Y + 85
const TOOL_Y = 650

function Tool({ cx, name, delay }: { cx: number; name: string; delay: number }) {
  const { step, initial, t } = useSlide()
  return (
    <motion.g
      initial={initial}
      animate={step >= 1 ? 'shown' : 'hidden'}
      variants={{
        hidden: { opacity: 0, scale: 0.3, x: 960 - cx, y: Y - TOOL_Y },
        shown: { opacity: 1, scale: 1, x: 0, y: 0 },
      }}
      transition={t.spring('bouncy', delay)}
      style={{ transformBox: 'fill-box', transformOrigin: 'center' }}
    >
      <rect x={cx - 180} y={TOOL_Y - 42} width={360} height={84} rx={42} fill="var(--surface-2)" stroke="var(--trace)" strokeWidth={3} />
      <text x={cx} y={TOOL_Y + 12} textAnchor="middle" fontSize={34} fontFamily="var(--font-mono)" fill="var(--ink)">
        {name}
      </text>
    </motion.g>
  )
}

function AgentMcp() {
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Svg>
        <DrawPath d={`M900,${MCP_BOTTOM} C900,560 770,540 770,${TOOL_Y - 42}`} at={1} delay={0.2} />
        <DrawPath d={`M1020,${MCP_BOTTOM} C1020,560 1150,540 1150,${TOOL_Y - 42}`} at={1} delay={0.3} />
        {/* Tools are drawn before the MCP box so they emerge from behind it. */}
        <Tool cx={770} name="search_traces" delay={0.1} />
        <Tool cx={1150} name="find_errors" delay={0.22} />
        <NodeBox cx={330} cy={Y} w={420} label="AI agent" sub="coding agent" />
        <Arrow from={[560, Y]} to={[730, Y]} delay={0.3} />
        <NodeBox cx={960} cy={Y} w={420} label="MCP server" sub="tools" delay={0.2} />
        <Arrow from={[1190, Y]} to={[1360, Y]} delay={0.55} />
        <NodeBox cx={1590} cy={Y} w={420} label="Traces" sub="Jaeger · App Insights" delay={0.4} accent />
      </Svg>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 830, textAlign: 'center' }}>
        <Words text="The agent reads the same traces you do." className="body" at={1} delay={0.8} stagger={0.05} />
      </div>
    </div>
  )
}

export default { id: 'agent-mcp', title: 'Agent → MCP → Traces', steps: 2, Component: AgentMcp } satisfies SlideDef
