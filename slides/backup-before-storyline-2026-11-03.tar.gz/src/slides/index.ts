import type { SlideDef } from '../deck/types'
import coldOpen from './01-cold-open'
import title from './02-title'
import client from './03-client'
import builtByAi from './04-built-by-ai'
import howWillYouKnow from './05-how-will-you-know'
import threeSignals from './06-three-signals'
import architecture from './07-architecture'
import traceparent from './08-traceparent'
import demoClick from './09-demo-click'
import instrumentation from './10-instrumentation'
import waterfall from './11-waterfall'
import localToCloud from './12-local-to-cloud'
import demoCloud from './13-demo-cloud'
import slowPage from './14-slow-page'
import nPlusOne from './15-n-plus-one'
import nPlusOneCode from './16-n-plus-one-code'
import whoDecidedAgain from './17-who-decided-again'
import agentMcp from './18-agent-mcp'
import demoAgent from './19-demo-agent'
import fixed from './20-fixed'
import loop from './21-loop'
import takeaways from './22-takeaways'
import closing from './23-closing'
import thanks from './24-thanks'

export const slides: SlideDef[] = [
  coldOpen,
  title,
  client,
  builtByAi,
  howWillYouKnow,
  threeSignals,
  architecture,
  traceparent,
  demoClick,
  instrumentation,
  waterfall,
  localToCloud,
  demoCloud,
  slowPage,
  nPlusOne,
  nPlusOneCode,
  whoDecidedAgain,
  agentMcp,
  demoAgent,
  fixed,
  loop,
  takeaways,
  closing,
  thanks,
]
