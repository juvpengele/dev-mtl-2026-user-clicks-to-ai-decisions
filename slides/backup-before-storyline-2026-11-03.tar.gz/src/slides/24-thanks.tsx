import { motion } from 'motion/react'
import { QRCodeSVG } from 'qrcode.react'
import { Words } from '../components/Words'
import { talk } from '../config'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

function Thanks() {
  const { initial, t } = useSlide()
  const fade = (delay: number) => ({
    initial: initial === false ? false : { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: t.spring('soft', delay),
  })
  return (
    <div className="slide" style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
      <div>
        <Words text="Thank you" className="huge" spring="bouncy" />
        <motion.div {...fade(0.5)} style={{ fontSize: 64, fontWeight: 750, marginTop: 56 }}>
          {talk.speaker}
        </motion.div>
        <motion.div {...fade(0.65)} className="mono" style={{ fontSize: 40, color: 'var(--ink-2)', marginTop: 20 }}>
          {talk.contact}
        </motion.div>
        <motion.div {...fade(0.8)} className="mono" style={{ fontSize: 36, color: 'var(--trace)', marginTop: 48 }}>
          {talk.repoUrl.replace(/^https?:\/\//, '')}
        </motion.div>
      </div>
      <motion.div
        initial={initial === false ? false : { opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={t.spring('bouncy', 0.9)}
        style={{ padding: 32, background: '#f6f7f9', borderRadius: 32, lineHeight: 0 }}
      >
        {/* Generated locally at render time: no network needed. */}
        <QRCodeSVG value={talk.repoUrl} size={440} bgColor="#f6f7f9" fgColor="#050608" level="M" />
      </motion.div>
    </div>
  )
}

export default { id: 'thanks', title: 'Thank you', steps: 1, Component: Thanks } satisfies SlideDef
