import { motion } from 'motion/react'
import { Words } from '../components/Words'
import { talk } from '../config'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

function Title() {
  const { initial, t } = useSlide()
  return (
    <div className="slide left">
      <Words text={talk.titleLine1} className="title" spring="bouncy" stagger={0.08} style={{ fontSize: 124 }} />
      <motion.div
        initial={initial === false ? false : { scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={t.spring('soft', 0.55)}
        style={{ width: 280, height: 10, borderRadius: 5, background: 'var(--trace)', originX: 0, margin: '48px 0 40px' }}
      />
      <Words text={talk.titleLine2} className="body" delay={0.7} stagger={0.05} style={{ fontSize: 60, color: 'var(--ink-2)' }} />
      <motion.div
        className="label"
        initial={initial === false ? false : { opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={t.spring('soft', 1.4)}
        style={{ marginTop: 120 }}
      >
        <span style={{ color: 'var(--ink)' }}>{talk.speaker}</span> · {talk.event} · {talk.city} · {talk.date}
      </motion.div>
    </div>
  )
}

export default { id: 'title', title: 'Title', steps: 1, Component: Title } satisfies SlideDef
