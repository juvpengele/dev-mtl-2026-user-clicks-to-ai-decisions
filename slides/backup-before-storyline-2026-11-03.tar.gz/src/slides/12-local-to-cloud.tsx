import { motion } from 'motion/react'
import { Arrow, NodeBox, Svg } from '../components/Diagram'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

function LocalToCloud() {
  const { step, initial, t } = useSlide()
  const cloud = step >= 1
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div className="label" style={{ position: 'absolute', left: 140, top: 110 }}>
        Local <span style={{ color: 'var(--ink)' }}>→</span> Cloud
      </div>
      <Svg>
        <NodeBox cx={270} cy={540} w={340} label="App" sub="devmtl-seats" />
        <Arrow from={[460, 540]} to={[570, 540]} delay={0.2} />
        <text x={515} y={500} textAnchor="middle" fontSize={26} fontFamily="var(--font-mono)" fill="var(--muted)">
          OTLP
        </text>
        <NodeBox cx={820} cy={540} w={460} label="Collector" sub="OpenTelemetry" delay={0.3} accent />
        <Arrow from={[1070, 515]} to={[1280, 360]} delay={0.6} />
        <NodeBox cx={1560} cy={330} w={520} label="Jaeger" sub="local" delay={0.7} />
        <Arrow from={[1070, 565]} to={[1280, 720]} at={1} />
        <NodeBox cx={1560} cy={750} w={520} label="Application Insights" sub="Azure · cloud" at={1} delay={0.3} />
      </Svg>
      <motion.div
        className="mono"
        initial={initial}
        animate={cloud ? 'shown' : 'hidden'}
        variants={{ hidden: { opacity: 0, scale: 0.6 }, shown: { opacity: 1, scale: 1 } }}
        transition={t.spring('bouncy', 1.2)}
        style={{ position: 'absolute', left: 0, right: 0, top: 900, textAlign: 'center', fontSize: 56, color: 'var(--ink-2)' }}
      >
        Code changes: <span style={{ color: 'var(--ok)', fontWeight: 800 }}>0</span>
      </motion.div>
    </div>
  )
}

export default { id: 'local-to-cloud', title: 'Local → Cloud', steps: 2, Component: LocalToCloud } satisfies SlideDef
