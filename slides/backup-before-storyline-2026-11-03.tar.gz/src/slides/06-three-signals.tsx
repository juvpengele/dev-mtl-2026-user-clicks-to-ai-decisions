import { motion } from 'motion/react'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

const ITEMS = ['Traces', '·', 'Metrics', '·', 'Logs']

// Hex rather than CSS variables: these colors are interpolated by motion.
const INK = '#f6f7f9'
const TRACE = '#ffb224'
const MUTED = '#6c7484'

function ThreeSignals() {
  const { step, initial, t } = useSlide()
  const focus = step >= 1
  return (
    <div className="slide">
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 48 }}>
        {ITEMS.map((w, i) => {
          const isTraces = i === 0
          const isDot = w === '·'
          const rest = { opacity: 1, scale: 1, x: 0, color: isDot ? MUTED : INK }
          const focused = isTraces
            ? { opacity: 1, scale: 1.5, x: 0, color: TRACE }
            : { opacity: 0.16, scale: 0.85, x: 150, color: isDot ? MUTED : INK }
          return (
            <motion.span
              key={i}
              className="title"
              initial={initial === false ? false : { opacity: 0, y: 60, filter: 'blur(14px)' }}
              animate={{ ...(focus ? focused : rest), y: 0, filter: 'blur(0px)' }}
              transition={focus ? t.spring(isTraces ? 'bouncy' : 'soft') : t.spring('soft', i * 0.14)}
              style={{
                fontSize: 120,
                display: 'inline-block',
                textShadow: focus && isTraces ? '0 0 60px var(--trace-glow)' : undefined,
              }}
            >
              {w}
            </motion.span>
          )
        })}
      </div>
    </div>
  )
}

export default { id: 'three-signals', title: 'Traces · Metrics · Logs', steps: 2, Component: ThreeSignals } satisfies SlideDef
