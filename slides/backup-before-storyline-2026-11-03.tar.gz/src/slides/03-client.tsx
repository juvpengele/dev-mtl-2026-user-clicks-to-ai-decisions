import { motion } from 'motion/react'
import { Typewriter } from '../components/Typewriter'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

function Client() {
  const { initial, t } = useSlide()
  return (
    <div className="slide left" style={{ paddingLeft: 260 }}>
      <motion.div
        initial={initial === false ? false : { opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={t.spring('soft')}
        style={{ display: 'flex', alignItems: 'center', gap: 24, marginBottom: 28 }}
      >
        <span
          style={{
            width: 84,
            height: 84,
            borderRadius: 42,
            background: 'var(--surface-2)',
            border: '2px solid var(--line)',
            display: 'grid',
            placeItems: 'center',
            fontSize: 34,
            fontWeight: 800,
          }}
        >
          DM
        </span>
        <span style={{ fontSize: 38, fontWeight: 700 }}>DevMTL organizers</span>
      </motion.div>
      <motion.div
        initial={initial === false ? false : { opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={t.spring('bouncy', 0.15)}
        style={{
          originX: 0,
          originY: 0,
          maxWidth: 1300,
          padding: '48px 60px',
          background: 'var(--surface-2)',
          borderRadius: '12px 48px 48px 48px',
          fontSize: 64,
          fontWeight: 550,
          lineHeight: 1.3,
        }}
      >
        <Typewriter text="We need an app so people can reserve a seat for the next meetup." delay={0.7} cps={36} />
      </motion.div>
    </div>
  )
}

export default { id: 'client', title: 'The client', steps: 1, Component: Client } satisfies SlideDef
