import { motion } from 'motion/react'
import { NP, NPlusOneFrame, px, qStart, qTop, QueryCounter, Q_DUR, reqEnd } from '../components/NPlusOne'
import { useCountTo } from '../components/useCountTo'
import { Words } from '../components/Words'
import { useSlide } from '../deck/SlideContext'
import type { SlideDef } from '../deck/types'

/**
 * The big reveal. Step 1: locally, 10 events = 11 queries, looks fine.
 * Step 2: production, 100 events. Queries cascade, accelerating, to 101.
 * Step 3: every query turns red and the pattern gets its name.
 */
function NPlusOne() {
  const { step, initial, t } = useSlide()
  const prod = step >= 1
  const named = step >= 2
  const n = Math.floor(
    useCountTo(prod ? 101 : 11, {
      duration: prod ? 3.8 : 1.1,
      delay: prod ? 0.2 : 0.5,
      ease: prod ? 'easeIn' : 'linear',
      backDuration: 0.5,
    }),
  )

  return (
    <NPlusOneFrame endMs={reqEnd(n)}>
      {Array.from({ length: n }, (_, i) => (
        <motion.div
          key={i}
          initial={initial === false ? false : { opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1, backgroundColor: named ? '#ff5468' : i === 0 ? '#f6f7f9' : '#b9c0cc' }}
          transition={{ default: t.tween(0.08, 0, 'easeOut'), backgroundColor: t.tween(0.25, named ? i * 0.006 : 0) }}
          style={{
            position: 'absolute',
            left: NP.left + px(qStart(i)),
            top: qTop(i),
            width: px(Q_DUR),
            height: NP.qH,
            borderRadius: 2,
            originX: 0,
          }}
        />
      ))}
      <QueryCounter
        queries={n}
        ms={reqEnd(n)}
        note={prod ? '100 events · production' : '10 events · local'}
        color={named ? 'var(--bad)' : 'var(--ink)'}
      />
      <div style={{ position: 'absolute', left: NP.left, top: 730 }}>
        <Words text="N+1" className="huge" at={2} delay={0.6} spring="bouncy" from="scale" style={{ color: 'var(--bad)' }} />
        <Words text="1 query for the list + 1 per event" className="body" at={2} delay={0.9} stagger={0.04} />
      </div>
    </NPlusOneFrame>
  )
}

export default { id: 'n-plus-one', title: 'N+1: 11 → 101 queries', steps: 3, Component: NPlusOne } satisfies SlideDef
