import type { ComponentType } from 'react'

export interface SlideDef {
  /** Stable id. Also the heading used for this slide in src/notes.md. */
  id: string
  /** Short name shown in the overview and presenter view. */
  title: string
  /** Number of steps (clicks) on this slide. 1 = no in-slide animation steps. */
  steps: number
  Component: ComponentType
}

export interface DeckPosition {
  slide: number // 0-based
  step: number // 0-based
}
