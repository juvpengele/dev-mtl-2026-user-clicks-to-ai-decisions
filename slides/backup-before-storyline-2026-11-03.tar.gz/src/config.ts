// Talk metadata. Edit the placeholders before the talk.
export const talk = {
  titleLine1: 'From User Clicks to AI Decisions',
  titleLine2: 'Full-Stack Observability with React & OpenTelemetry',
  speaker: 'Juvenal',
  event: 'slash/dev MTL',
  city: 'Montréal',
  date: 'November 27, 2026',
  // Placeholders: replace before the talk.
  contact: 'your-handle@example.com',
  repoUrl: 'https://github.com/your-handle/devmtl-seats',
  // Planned talk length in minutes; the presenter timer turns amber/red against it.
  durationMinutes: 45,
}
